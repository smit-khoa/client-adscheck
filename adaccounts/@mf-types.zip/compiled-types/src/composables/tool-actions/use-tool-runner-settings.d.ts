export declare function useToolRunnerSettings(): {
    threads: import("vue").Ref<number, number>;
    delayMs: import("vue").Ref<number, number>;
};
