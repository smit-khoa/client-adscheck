import { type InjectionKey } from 'vue';
import type { ToolActionsInstance } from './create-tool-actions';
export declare const TOOL_ACTIONS_KEY: InjectionKey<ToolActionsInstance>;
export declare function provideToolActions(instance: ToolActionsInstance): void;
export declare function useToolActionsContext(): ToolActionsInstance;
