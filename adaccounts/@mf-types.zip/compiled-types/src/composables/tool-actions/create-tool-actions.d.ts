import { type ComputedRef, type Ref } from 'vue';
import type { ToolFunction } from '@/types/tool-action.types';
export interface ToolActionsOptions {
    functions: ToolFunction[];
    orderKey: string;
    enabledKey: string;
}
export interface ToolActionsInstance {
    orderedFunctions: Ref<ToolFunction[]>;
    expandedIds: Ref<Set<string>>;
    enabledIds: Ref<Set<string>>;
    selectedFunctionId: Ref<string | null>;
    selectedFunctionIds: Ref<string[]>;
    expandedStepIds: Ref<Set<string>>;
    enabledFunctions: ComputedRef<ToolFunction[]>;
    selectedFunction: ComputedRef<ToolFunction | null>;
    selectedFunctions: ComputedRef<ToolFunction[]>;
    valuesFor: (fn: ToolFunction) => Record<string, string | boolean | File>;
    selectFunction: (id: string) => void;
    removeSelectedFunction: (id: string) => void;
    reorderSelectedFunctions: (nextIds: string[]) => void;
    toggleStepExpanded: (id: string) => void;
    clearSelectedFunction: () => void;
    toggleExpand: (id: string) => void;
    toggleEnabled: (id: string) => void;
    collapse: () => void;
    reorder: (next: ToolFunction[]) => void;
}
export declare function createToolActions(options: ToolActionsOptions): ToolActionsInstance;
