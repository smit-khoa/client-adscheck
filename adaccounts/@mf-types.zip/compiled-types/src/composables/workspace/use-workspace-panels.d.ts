export declare function useWorkspacePanels(): {
    panelOneOpen: import("vue").Ref<boolean, boolean>;
    panelTwoOpen: import("vue").Ref<boolean, boolean>;
    panelOneSize: import("vue").Ref<number, number>;
    panelTwoSize: import("vue").Ref<number, number>;
};
