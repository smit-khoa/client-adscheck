/**
 * Get the BUSINESS_MANAGER access token, fetching once and caching in memory.
 * Concurrent callers share one in-flight request. Throws a clear Error if it
 * can't be resolved (e.g. not logged in / FB schema changed). Reuses the shared
 * graphql() helper (auth via fb_dtsg + lsd).
 */
export declare function getBmToken(forceRefresh?: boolean): Promise<string>;
/** Drop the cached BM token (in-memory + persisted) so the next call refetches. */
export declare function resetBmToken(): Promise<void>;
