export declare function getLegacyGraphqlToken(forceRefresh?: boolean): Promise<string>;
export declare function resetLegacyGraphqlToken(): Promise<void>;
