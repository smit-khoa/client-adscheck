import type { FbTokenBundle } from './types';
export type TokenSlot = 'token_b' | 'token_g' | 'token_i' | 'token_graphql';
export interface CachedToken {
    access_token: string;
    date: number;
}
export interface SessionMetadata {
    user_id?: string;
    fb_dtsg?: string;
    fb_dtsg_ag?: string;
    lsd?: string;
    user_name?: string;
}
export interface StoredData extends SessionMetadata {
    token_b?: CachedToken;
    token_g?: CachedToken;
    token_i?: CachedToken;
    token_graphql?: CachedToken;
}
/** Read the stored bundle from the extension. null when absent/unreadable. */
export declare function getStorageData(): Promise<StoredData | null>;
/** Merge `patch` into the stored bundle and write it back (best-effort). */
export declare function updateStorageData(patch: Partial<StoredData>): Promise<void>;
/** True when a cached token exists and is within the 6h TTL. */
export declare function isTokenFresh(token: CachedToken | undefined, now: number): boolean;
export declare function parseSessionMetadata(text: string): SessionMetadata;
export declare function sessionFromBundle(bundle: FbTokenBundle): SessionMetadata;
export declare function readCachedToken(slot: TokenSlot, expectedUserId?: string): Promise<string | null>;
export declare function writeCachedToken(slot: TokenSlot, token: string, session?: SessionMetadata): Promise<void>;
/** Expire one stored token (used on auth error) by zeroing its date. */
export declare function invalidateStoredToken(which: TokenSlot): Promise<void>;
