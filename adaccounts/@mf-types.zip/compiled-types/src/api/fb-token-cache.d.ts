export interface CachedToken {
    access_token: string;
    date: number;
}
export interface StoredData {
    user_id?: string;
    fb_dtsg?: string;
    fb_dtsg_ag?: string;
    lsd?: string;
    user_name?: string;
    token_b?: CachedToken;
    token_g?: CachedToken;
}
/** Read + decrypt the stored bundle from the extension. null when absent/unreadable. */
export declare function getStorageData(): Promise<StoredData | null>;
/** Merge `patch` into the stored bundle and write it back encrypted (best-effort). */
export declare function updateStorageData(patch: Partial<StoredData>): Promise<void>;
/** True when a cached token exists and is within the 6h TTL. */
export declare function isTokenFresh(token: CachedToken | undefined, now: number): boolean;
/** Expire one stored token (used on auth error) by zeroing its date. */
export declare function invalidateStoredToken(which: 'token_b' | 'token_g'): Promise<void>;
