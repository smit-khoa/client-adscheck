export type TokenPurpose = 'readGraph' | 'powerEditorAction' | 'businessManagerAction' | 'legacyGraphql' | 'sessionGraphql';
export type TokenSlot = 'token_b' | 'token_g' | 'token_i' | 'token_graphql' | 'session';
export interface TokenResolution {
    slot: TokenSlot;
    access_token?: string;
    fb_dtsg?: string;
    lsd?: string;
    user_id?: string;
}
export interface TokenPolicyOptions {
    readPreference?: 'current' | 'auto';
    autoFallbackSlots?: Array<'token_b' | 'token_g'>;
}
export declare function getTokenForPurpose(purpose: TokenPurpose, options?: TokenPolicyOptions): Promise<TokenResolution>;
export declare function resetTokenForSlot(slot: TokenSlot): Promise<void>;
