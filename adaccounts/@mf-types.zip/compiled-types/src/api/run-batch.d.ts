import type { AdAccount } from '../features/account-list';
import type { RowResult } from './types';
interface RunBatchOptions {
    /** Max accounts processed concurrently ("Luồng"). */
    threads: number;
    /** Delay in ms between launching each worker ("Delay"). */
    delayMs: number;
}
type Worker = (account: AdAccount, index: number) => Promise<{
    ok: boolean;
    message: string;
    patch?: Partial<AdAccount>;
}>;
/**
 * Run `worker` over `accounts` with bounded concurrency and a delay between
 * launches (mirrors the reference tools' anti-rate-limit behaviour). Never
 * rejects — every account yields a RowResult, errors included.
 */
export declare function runBatch(accounts: AdAccount[], worker: Worker, { threads, delayMs }: RunBatchOptions): Promise<RowResult[]>;
export {};
