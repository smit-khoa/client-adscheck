import type { FbTokenBundle } from './types';
export declare function parseTokens(html: string): FbTokenBundle | null;
/**
 * Get the FB token bundle, fetching once and caching in memory/storage. Throws a
 * clear Error if tokens can't be parsed (e.g. not logged in / FB markup changed).
 */
export declare function getToken(forceRefresh?: boolean): Promise<FbTokenBundle>;
/** Drop the cached token (in-memory + persisted) so the next call refetches. */
export declare function resetToken(): Promise<void>;
