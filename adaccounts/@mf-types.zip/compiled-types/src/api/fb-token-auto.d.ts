export declare function getAutoToken(forceRefresh?: boolean): Promise<string>;
export declare function resetAutoToken(): Promise<void>;
