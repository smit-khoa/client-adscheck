import type { ToolRunner } from './index';
export declare const changeInfoAccount: ToolRunner;
