import type { AdAccount } from '../../features/adaccounts';
export interface ToolRunContext {
    allAccounts: AdAccount[];
    selectedCount?: number;
    delayMs?: number;
}
export type ToolValue = string | boolean | File;
export type ToolValues = Record<string, ToolValue>;
export type PrimitiveToolValues = Record<string, string | boolean>;
export type ToolRunner = (account: AdAccount, values: ToolValues, index: number, ctx?: ToolRunContext) => Promise<{
    ok: boolean;
    message: string;
    skipped?: boolean;
    patch?: Partial<AdAccount>;
}>;
export declare function primitiveToolValues(values: ToolValues): PrimitiveToolValues;
export declare const TOOL_RUNNERS: Record<string, ToolRunner>;
export declare function hasRunner(functionId: string): boolean;
