import type { AdAccount } from '../../features/account-list';
export interface ToolRunContext {
    allAccounts: AdAccount[];
    delayMs?: number;
}
export type ToolRunner = (account: AdAccount, values: Record<string, string | boolean>, index: number, ctx?: ToolRunContext) => Promise<{
    ok: boolean;
    message: string;
    patch?: Partial<AdAccount>;
}>;
export declare const TOOL_RUNNERS: Record<string, ToolRunner>;
export declare function hasRunner(functionId: string): boolean;
