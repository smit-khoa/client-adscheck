import type { ToolRunner } from './index';
export declare const importCampaignXlsx: ToolRunner;
