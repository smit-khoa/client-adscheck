import type { ToolRunner } from './index';
export declare const spendLimit: ToolRunner;
