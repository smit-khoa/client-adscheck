import type { ToolRunner } from './index';
export declare const removePartnerAccount: ToolRunner;
