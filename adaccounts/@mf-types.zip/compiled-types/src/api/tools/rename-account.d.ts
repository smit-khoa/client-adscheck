import type { ToolRunner } from './index';
export declare const renameAccount: ToolRunner;
