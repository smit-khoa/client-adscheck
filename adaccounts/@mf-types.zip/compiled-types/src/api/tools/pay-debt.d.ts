import type { ToolRunner } from './index';
export declare const payDebt: ToolRunner;
