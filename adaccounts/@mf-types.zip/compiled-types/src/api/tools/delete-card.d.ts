import type { ToolRunner } from './index';
export declare const deleteCard: ToolRunner;
