import { type GraphResult } from '../types';
export interface AccountUser {
    id: string;
    name?: string;
    is_active?: boolean;
}
interface UserPermission {
    user?: {
        id?: string;
    };
    business?: {
        id?: string;
    };
}
export interface AccountAdminContext {
    owner?: string | null;
    owner_business?: {
        id?: string;
    } | null;
    users?: {
        data?: AccountUser[];
    };
    userpermissions?: {
        data?: UserPermission[];
    };
}
export declare function parseUids(value: unknown): string[];
export declare function bareAccountId(accountId: string): string;
export declare function getBmIdForCurrentUser(ctx: AccountAdminContext, currentUserId: string): string | null;
export declare function loadAccountAdminContext(adId: string): Promise<GraphResult<AccountAdminContext>>;
export declare function loadSelfRemoveContext(adId: string): Promise<GraphResult<AccountAdminContext>>;
export declare function shouldScrapeHiddenAdmins(normalUsers: AccountUser[], permissionCount: number): Promise<{
    scrape: boolean;
    fallback: boolean;
}>;
export declare function scrapeHiddenAdmins(adId: string, ownerBusinessId: string | null): Promise<string[]>;
export interface RemoveAttempt {
    method: 'users_delete' | 'userpermissions_delete';
    ok: boolean;
    reason?: string;
}
export interface RemoveOneResult {
    ok: boolean;
    message: string;
    methodUsed: RemoveAttempt['method'] | null;
    attempts: RemoveAttempt[];
}
export declare function removeOneAdmin(adId: string, uid: string, bmId: string | null): Promise<RemoveOneResult>;
export declare const wait: (ms: number) => Promise<void>;
export {};
