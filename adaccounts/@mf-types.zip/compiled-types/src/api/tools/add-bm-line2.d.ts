import type { ToolRunner } from './index';
export declare const addBmLine2: ToolRunner;
