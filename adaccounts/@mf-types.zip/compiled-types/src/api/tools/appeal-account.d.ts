import type { ToolRunner } from './index';
export declare const appealAccount: ToolRunner;
