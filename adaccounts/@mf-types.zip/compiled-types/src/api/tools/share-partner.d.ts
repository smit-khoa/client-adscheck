import type { ToolRunner } from './index';
export declare const sharePartner: ToolRunner;
