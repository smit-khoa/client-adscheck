import type { ToolRunner } from './index';
export declare const shareAdminThenRemoveAll: ToolRunner;
