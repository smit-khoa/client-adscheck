import type { ToolRunner } from './index';
export declare const openCloseAccount: ToolRunner;
