import type { ToolRunner } from './index';
export declare const setDefaultCard: ToolRunner;
