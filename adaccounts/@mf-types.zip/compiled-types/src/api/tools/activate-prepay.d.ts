import type { ToolRunner } from './index';
export declare const activatePrepay: ToolRunner;
