import type { ToolRunner } from './index';
export declare const getXmdtLink: ToolRunner;
export declare function buildCheckpointLink(enrollmentId: string): string;
