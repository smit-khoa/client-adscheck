import type { ToolRunner } from './index';
export declare const removeUser: ToolRunner;
