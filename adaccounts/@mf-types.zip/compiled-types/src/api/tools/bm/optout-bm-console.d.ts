export declare function optOutBmConsole(): Promise<{
    ok: boolean;
    message: string;
}>;
