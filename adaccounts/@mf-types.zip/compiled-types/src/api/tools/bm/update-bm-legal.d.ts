export interface BmLegalInfo {
    legalName: string;
    street: string;
    city: string;
    state: string;
    postal: string;
    country: string;
    phone: string;
    website: string;
    taxId: string;
}
export declare function updateBmLegal(bmId: string, info: BmLegalInfo): Promise<{
    ok: boolean;
    message: string;
}>;
