export declare function createPageInBm(bmId: string, pageName: string): Promise<{
    ok: boolean;
    message: string;
}>;
