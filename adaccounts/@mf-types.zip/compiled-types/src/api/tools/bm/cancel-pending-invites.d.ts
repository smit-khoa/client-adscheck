export type CancelMode = 'all' | 'by-email';
/**
 * Cancel pending invites in one BM. Returns a per-BM outcome (the runner calls
 * this once per selected BM). Never throws.
 */
export declare function cancelPendingInvites(bmId: string, mode: CancelMode, emails: string[]): Promise<{
    ok: boolean;
    message: string;
    warn?: boolean;
}>;
