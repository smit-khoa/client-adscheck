export interface AppealLinkResult {
    bmId: string;
    ok: boolean;
    link?: string;
    status?: string;
    message: string;
}
export declare function getAppealLink(bmId: string): Promise<AppealLinkResult>;
