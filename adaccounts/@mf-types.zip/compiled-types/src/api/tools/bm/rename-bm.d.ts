export type RenameBmMode = 'meofb' | 'xmeta';
export declare function renameBm(bmId: string, name: string, mode?: RenameBmMode): Promise<{
    ok: boolean;
    message: string;
}>;
