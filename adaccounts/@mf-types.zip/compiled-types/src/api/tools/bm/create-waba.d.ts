export type WabaApiMode = '0' | '2' | '3' | '4';
export declare function createWaba(bmId: string, opts: {
    name: string;
    mode: WabaApiMode;
}): Promise<{
    ok: boolean;
    message: string;
}>;
