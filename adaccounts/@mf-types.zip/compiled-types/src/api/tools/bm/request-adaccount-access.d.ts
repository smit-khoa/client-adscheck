export declare function requestAdAccountAccess(bmId: string, adId: string): Promise<{
    ok: boolean;
    message: string;
}>;
