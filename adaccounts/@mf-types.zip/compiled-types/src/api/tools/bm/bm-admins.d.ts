export interface BmAdminRow {
    id: string;
    name: string;
    email: string;
    role: string;
    [key: string]: string | number;
}
export declare function listBmAdmins(bmId: string): Promise<{
    ok: true;
    rows: BmAdminRow[];
} | {
    ok: false;
    message: string;
}>;
export declare function removeBmAdmin(bmId: string, userId: string): Promise<{
    ok: boolean;
    message: string;
}>;
export declare function setBmAdminRole(bmId: string, userId: string, role: 'admin' | 'employee'): Promise<{
    ok: boolean;
    message: string;
}>;
