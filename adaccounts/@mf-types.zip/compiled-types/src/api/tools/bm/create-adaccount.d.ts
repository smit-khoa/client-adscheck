export type CreateAdAccountMode = 'meofb' | 'xmeta';
export declare function createAdAccount(bmId: string, opts: {
    name: string;
    currency: string;
    timezoneId: string;
    mode: CreateAdAccountMode;
}): Promise<{
    ok: boolean;
    message: string;
}>;
