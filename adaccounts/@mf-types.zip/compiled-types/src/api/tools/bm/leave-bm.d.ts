export type LeaveAccountKind = 'fb' | 'ig';
/**
 * Remove the logged-in user from one BM. `fb` runs the real REST delete (GraphQL
 * fallback); `ig` returns a clear "not implemented" error. Never throws.
 */
export declare function leaveBm(bmId: string, kind?: LeaveAccountKind): Promise<{
    ok: boolean;
    message: string;
}>;
