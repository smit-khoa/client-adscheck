export declare function removeIgAccount(bmId: string): Promise<{
    ok: boolean;
    message: string;
    warn?: boolean;
}>;
