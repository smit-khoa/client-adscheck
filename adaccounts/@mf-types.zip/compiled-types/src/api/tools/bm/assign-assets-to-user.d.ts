export type AssignAssetType = 'ad-account' | 'page' | 'pixel';
export type AssignRole = 'manage' | 'analyze';
export declare function assignAssetsToUser(bmId: string, userId: string, assetType: AssignAssetType, assetIds: string[], role: AssignRole): Promise<{
    ok: boolean;
    message: string;
}>;
