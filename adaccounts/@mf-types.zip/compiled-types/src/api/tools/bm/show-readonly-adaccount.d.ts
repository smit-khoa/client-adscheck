export declare function showReadonlyAdAccount(bmId: string): Promise<{
    ok: boolean;
    message: string;
    warn?: boolean;
}>;
