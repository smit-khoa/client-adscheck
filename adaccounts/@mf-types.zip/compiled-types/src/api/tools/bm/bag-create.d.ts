export declare function createBag(bmId: string, name: string): Promise<{
    ok: boolean;
    message: string;
}>;
