export type RemovePageMode = 'all' | 'id';
export declare function removePage(bmId: string, mode: RemovePageMode, ids: string[]): Promise<{
    ok: boolean;
    message: string;
    warn?: boolean;
}>;
