export type CreateBmMode = '350' | '50' | 'over' | 'api1' | 'api2' | 'api3';
/**
 * Create one BM named `name` using `mode`. `over` = REST create; the rest =
 * GraphQL CreateBusiness mutations. Never throws.
 */
export declare function createBm(name: string, mode: CreateBmMode): Promise<{
    ok: boolean;
    message: string;
}>;
