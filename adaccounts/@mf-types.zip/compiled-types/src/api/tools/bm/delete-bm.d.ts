export declare function deleteBm(bmId: string): Promise<{
    ok: boolean;
    message: string;
}>;
