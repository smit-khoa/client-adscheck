export type ClaimPageMode = 'meofb' | 'xmeta';
export declare function claimPage(bmId: string, pageId: string, mode: ClaimPageMode): Promise<{
    ok: boolean;
    message: string;
}>;
