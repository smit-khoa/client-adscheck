export declare function reactivatePage(bmId: string): Promise<{
    ok: boolean;
    message: string;
    warn?: boolean;
}>;
