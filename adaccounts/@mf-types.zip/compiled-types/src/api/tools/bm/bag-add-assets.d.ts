export type BagAssetType = 'ad-account' | 'page' | 'pixel';
export declare function bagAddAssets(bmId: string, bagId: string, assetType: BagAssetType, assetIds: string[]): Promise<{
    ok: boolean;
    message: string;
}>;
