export type ShareRole = 'admin' | 'employee';
export interface ShareBmResult {
    ok: boolean;
    message: string;
}
export declare const ADMIN_TASKS: string[];
export declare const EMPLOYEE_TASKS: string[];
/** Add 1 email to 1 BM. REST primary; on error → GraphQL fallback. Never throws. */
export declare function shareBmUser(bmId: string, email: string, role: ShareRole): Promise<ShareBmResult>;
