export type ShareRole = 'admin' | 'employee';
export interface ShareBmResult {
    ok: boolean;
    message: string;
}
/** Add 1 email to 1 BM. REST primary; on error → GraphQL fallback. Never throws. */
export declare function shareBmUser(bmId: string, email: string, role: ShareRole): Promise<ShareBmResult>;
