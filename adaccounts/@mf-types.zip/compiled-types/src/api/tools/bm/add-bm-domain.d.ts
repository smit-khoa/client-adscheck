export declare function addBmDomain(bmId: string, domain: string): Promise<{
    ok: boolean;
    message: string;
}>;
