export interface BagRow {
    id: string;
    name: string;
    assetCount: number;
    [key: string]: string | number;
}
export declare function listBags(bmId: string): Promise<{
    ok: true;
    rows: BagRow[];
} | {
    ok: false;
    message: string;
}>;
export declare function deleteBag(bmId: string, bagId: string): Promise<{
    ok: boolean;
    message: string;
}>;
