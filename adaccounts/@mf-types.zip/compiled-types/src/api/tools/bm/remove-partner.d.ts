export type RemovePartnerMode = 'all' | 'id';
export declare function removePartner(bmId: string, mode: RemovePartnerMode, ids: string[]): Promise<{
    ok: boolean;
    message: string;
    warn?: boolean;
}>;
