export type RemoveShareMode = 'all' | 'die' | 'live' | 'id';
export declare function removeSharedAdAccount(bmId: string, mode: RemoveShareMode, ids: string[]): Promise<{
    ok: boolean;
    message: string;
    warn?: boolean;
}>;
