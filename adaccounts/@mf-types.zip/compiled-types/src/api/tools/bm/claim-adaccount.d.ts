export type ClaimMode = 'meofb' | 'xmeta-single' | 'xmeta-batch';
export declare function claimAdAccount(bmId: string, adId: string, mode: Exclude<ClaimMode, 'xmeta-batch'>): Promise<{
    ok: boolean;
    message: string;
}>;
export declare function claimAdAccountBatch(bmId: string, adIds: string[]): Promise<{
    ok: boolean;
    message: string;
}>;
