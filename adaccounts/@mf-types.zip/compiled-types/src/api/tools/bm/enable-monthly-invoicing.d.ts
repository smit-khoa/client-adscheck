export declare function enableMonthlyInvoicing(bmId: string): Promise<{
    ok: boolean;
    message: string;
}>;
