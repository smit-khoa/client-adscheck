import type { ToolRunner } from './index';
export declare const addUser: ToolRunner;
