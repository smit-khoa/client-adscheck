import { type GraphResult } from './types';
export type GraphTokenKind = 'POWER_EDITOR' | 'BUSINESS_MANAGER';
interface GraphOptions {
    method?: 'GET' | 'POST' | 'DELETE';
    params?: Record<string, string | number | boolean>;
    body?: Record<string, string | number | boolean>;
    version?: string;
    token?: GraphTokenKind;
}
/**
 * Call the public Graph REST API. `path` like `/act_123/...`; access_token +
 * standard format params are added automatically. Returns parsed JSON or a
 * normalized { error, message, code }. On an auth error it drops the cached
 * token and retries once with a fresh one.
 */
export declare function graph<T = unknown>(path: string, options?: GraphOptions): Promise<GraphResult<T>>;
interface GraphqlBody {
    doc_id: string;
    variables?: string;
    fb_api_req_friendly_name?: string;
}
/**
 * Call the internal GraphQL endpoint. Adds __a, fb_dtsg, lsd automatically and
 * strips the `for (;;);` anti-JSON-hijack prefix. `host` selects the domain
 * (www | business | adsmanager). Returns parsed data or normalized error.
 */
export declare function graphql<T = unknown>(body: GraphqlBody, host?: 'www' | 'business' | 'adsmanager'): Promise<GraphResult<T>>;
/** True when a parsed GraphQL/Graph response text contains the given marker. */
export declare function responseHasMarker(value: unknown, marker: string): boolean;
export {};
