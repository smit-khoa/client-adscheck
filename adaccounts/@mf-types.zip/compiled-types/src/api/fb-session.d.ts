export interface FacebookSessionResult {
    status: 'logged_in' | 'not_logged_in' | 'switched';
    user_id?: string;
    message?: string;
}
/** Drop the cached session so the next call probes Facebook again. */
export declare function invalidateFacebookSessionCache(): void;
/**
 * Probe the browser's live Facebook session before hydrating extension caches.
 * This mirrors the legacy Banzai login check so account switches/logout cannot
 * reuse token/data cached for a previous Facebook user.
 *
 * The result is cached for 1 minute to avoid repeated Banzai probes when the
 * user switches tabs inside the same app session. Call
 * `invalidateFacebookSessionCache()` if you need to force a fresh probe.
 */
export declare function checkFacebookSession(): Promise<FacebookSessionResult>;
