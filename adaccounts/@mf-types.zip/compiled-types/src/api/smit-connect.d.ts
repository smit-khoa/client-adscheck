import type { ExtFetchOptions } from './types';
/**
 * Read one key from the extension's chrome.storage.local. The extension returns
 * a `{ [key]: value }` object (chrome.storage semantics); we unwrap to the value.
 * Returns null when missing or the extension is unavailable.
 */
export declare function extStorageGet<T>(key: string): Promise<T | null>;
/** Write key/value pairs into the extension's chrome.storage.local. */
export declare function extStorageSet(items: Record<string, unknown>): Promise<void>;
/**
 * Fetch a URL through the extension's background `fetch`. Returns the response
 * body as a string (caller parses). Throws a clear Error when no extension is
 * available so batch runners can surface "extension not installed" per row.
 */
export declare function extFetch(url: string, options?: ExtFetchOptions): Promise<string>;
