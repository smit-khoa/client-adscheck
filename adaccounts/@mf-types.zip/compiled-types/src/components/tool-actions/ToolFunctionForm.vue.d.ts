import type { ToolFunction } from '@/types/tool-action.types';
type __VLS_Props = {
    fn: ToolFunction;
    selectedCount: number;
    showHeader?: boolean;
    variant?: 'default' | 'panel-two';
};
declare const _default: import("vue").DefineComponent<__VLS_Props, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<__VLS_Props> & Readonly<{}>, {
    variant: "default" | "panel-two";
    showHeader: boolean;
}, {}, {}, {}, string, import("vue").ComponentProvideOptions, false, {}, any>;
export default _default;
