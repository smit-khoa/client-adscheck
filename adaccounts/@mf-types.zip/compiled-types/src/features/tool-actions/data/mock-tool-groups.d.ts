import type { ToolFunction, ToolGroup } from '../types/tool-action.types';
export declare const TOOL_GROUPS: ToolGroup[];
export declare const TOOL_FUNCTIONS: ToolFunction[];
