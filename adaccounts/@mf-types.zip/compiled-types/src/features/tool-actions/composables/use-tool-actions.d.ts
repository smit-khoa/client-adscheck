import { type ToolActionsInstance } from './create-tool-actions';
export declare function useToolActions(): ToolActionsInstance;
