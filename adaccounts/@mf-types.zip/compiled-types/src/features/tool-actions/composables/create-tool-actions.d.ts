import { type ComputedRef, type Ref } from 'vue';
import type { ToolFunction } from '../types/tool-action.types';
export interface ToolActionsOptions {
    functions: ToolFunction[];
    orderKey: string;
    enabledKey: string;
}
export interface ToolActionsInstance {
    orderedFunctions: Ref<ToolFunction[]>;
    expandedIds: Ref<Set<string>>;
    enabledIds: Ref<Set<string>>;
    enabledFunctions: ComputedRef<ToolFunction[]>;
    valuesFor: (fn: ToolFunction) => Record<string, string | boolean>;
    toggleExpand: (id: string) => void;
    toggleEnabled: (id: string) => void;
    collapse: () => void;
    reorder: (next: ToolFunction[]) => void;
}
export declare function createToolActions(options: ToolActionsOptions): ToolActionsInstance;
