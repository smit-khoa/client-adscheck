import type { IconName } from '@mf2/shared-ui/icons';
export type ToolFieldType = 'text' | 'number' | 'textarea' | 'select' | 'switch' | 'file';
export interface ToolFieldOption {
    value: string;
    label: string;
}
export interface ToolFieldSchema {
    key: string;
    label: string;
    type: ToolFieldType;
    placeholder?: string;
    default?: string | number | boolean;
    options?: ToolFieldOption[];
    accept?: string;
    sensitive?: boolean;
    hint?: string;
    showWhen?: {
        key: string;
        equals: string;
    };
}
export interface ToolFunction {
    id: string;
    label: string;
    icon?: IconName;
    fields?: ToolFieldSchema[];
}
export interface ToolGroup {
    id: string;
    label: string;
    icon?: IconName;
    functions: ToolFunction[];
}
