export type AccountSelectionMode = 'explicit' | 'all-filtered';
export interface AccountSelectionState {
    selectedIds: Set<string>;
    mode: AccountSelectionMode;
    excludedIds: Set<string>;
}
