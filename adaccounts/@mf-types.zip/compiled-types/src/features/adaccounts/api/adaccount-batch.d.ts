import { type AdAccountSeed } from './adaccount-mappers';
interface RunAccountBatchOptions {
    seeds: AdAccountSeed[];
    fields: string[];
    concurrency: number;
    payment?: boolean;
}
export declare function runAccountBatch({ seeds, fields, concurrency, payment, }: RunAccountBatchOptions): Promise<Map<string, unknown>>;
export {};
