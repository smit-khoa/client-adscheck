import type { AdAccount, AdAccountAdminUser } from '../types/account-list.types';
export type AdAccountAdminAction = 'promote' | 'demote' | 'remove';
export interface AdAccountAdminActionResult {
    message: string;
    patch?: Partial<AdAccount>;
}
export declare function getCurrentFacebookUserId(): Promise<string | undefined>;
export declare function runAdAccountAdminAction(account: AdAccount, user: AdAccountAdminUser, action: AdAccountAdminAction): Promise<AdAccountAdminActionResult>;
export declare function roleLabelFromUser(user: AdAccountAdminUser): string;
