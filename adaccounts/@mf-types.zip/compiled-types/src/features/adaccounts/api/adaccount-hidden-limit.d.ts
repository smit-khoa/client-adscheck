import { type AdAccountSeed } from './adaccount-mappers';
export declare function runHiddenLimitQueue(seeds: AdAccountSeed[], concurrency: number): Promise<Map<string, {
    limit?: number;
    legacyId?: string;
} | undefined>>;
