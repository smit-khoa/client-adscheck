import type { BusinessManagerRow, LoadBusinessManagersConfig } from '../types/account-list.types';
export declare function fetchBusinessManagers(config?: LoadBusinessManagersConfig): Promise<BusinessManagerRow[]>;
