import type { CheckHoldResult } from './adaccount-check-hold';
import type { AdAccount, AdAccountAdminUser, OwnerBusiness } from '../types/account-list.types';
export interface AdAccountSeed {
    account_id: string;
    name?: string;
    account_status?: number;
    currency?: string;
    owner_business?: OwnerBusiness;
}
interface GraphConnection<T> {
    data?: T[];
}
interface AdAccountDetail extends AdAccountSeed {
    owner?: {
        id?: string;
        name?: string;
    } | string;
    agencies?: GraphConnection<{
        id?: string;
        name?: string;
        access_status?: string;
        permitted_roles?: string[];
    }>;
    created_time?: string;
    timezone_name?: string;
    timezone_offset_hours_utc?: number;
    disable_reason?: string | number;
    business_country_code?: string;
    is_prepay_account?: boolean;
    next_bill_date?: string;
    balance?: string | number;
    adtrust_dsl?: string | number;
    spend_cap?: string | number;
    amount_spent?: string | number;
    adspaymentcycle?: GraphConnection<{
        threshold_amount?: string | number;
    }>;
    insights?: GraphConnection<{
        spend?: string | number;
    }>;
    users?: GraphConnection<{
        id?: string;
        name?: string;
        role?: string | number;
        user_tasks?: string[];
        tasks?: string[];
        permissions?: string[];
        roles?: string[];
        is_active?: boolean;
    }>;
    userpermissions?: GraphConnection<{
        role?: string;
    }>;
}
export declare function normalizeAccountId(value: string | number | undefined): string;
export declare function toActId(accountId: string): string;
export declare function parseIdsText(value: string): string[];
export declare function isBusinessAccount(seed: AdAccountSeed): boolean;
export declare function matchesAccountType(seed: AdAccountSeed, accountType: 'all' | 'personal' | 'bm'): boolean;
export declare function classifyAdAccountUserRole(user: {
    role?: string | number;
    user_tasks?: string[];
    tasks?: string[];
    permissions?: string[];
    roles?: string[];
}): AdAccountAdminUser['role'];
export declare function mapAdAccountAdminUsers(detail: Pick<AdAccountDetail, 'users'>): AdAccountAdminUser[];
export declare function countAdAccountAdmins(detail: Pick<AdAccountDetail, 'users' | 'userpermissions'>): number | undefined;
export declare function summarizeAdAccountAdmins(users: AdAccountAdminUser[]): string | undefined;
export declare function mapAdAccountRow(seed: AdAccountSeed, detail?: unknown, payment?: unknown, hiddenLimit?: number, checkHold?: CheckHoldResult): AdAccount;
export {};
