import type { LoadAdAccountsConfig } from '../types/account-list.types';
export declare const DEFAULT_LOAD_ADACCOUNTS_CONFIG: LoadAdAccountsConfig;
export declare function normalizeLoadConfig(config?: Partial<LoadAdAccountsConfig>): LoadAdAccountsConfig;
export declare function buildDetailFields(config: LoadAdAccountsConfig, uid: string): string[];
export declare function buildPaymentFields(config: LoadAdAccountsConfig): string[];
