import { type AdAccountSeed } from './adaccount-mappers';
export interface CheckHoldResult {
    priskRestrictions?: unknown[];
    billingFlags?: string[];
    requiredWizardName?: string;
    billingAccountStatus?: string;
    isReauthRestricted?: boolean;
    isSdcRestricted?: boolean;
    holdNeed?: string;
}
export declare function runCheckHoldQueue(seeds: AdAccountSeed[], concurrency: number, hiddenLimitMap: Map<string, {
    legacyId?: string;
} | undefined>): Promise<Map<string, CheckHoldResult | undefined>>;
