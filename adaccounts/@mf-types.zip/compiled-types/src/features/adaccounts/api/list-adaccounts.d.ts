import type { AdAccount, LoadAdAccountsConfig } from '../types/account-list.types';
/**
 * Load ad accounts through the resilient BM/TKQC flow: lightweight seeds first,
 * detail/admin in Graph batch, and payment in a separate queue.
 */
export declare function fetchAdAccounts(config?: Partial<LoadAdAccountsConfig>): Promise<AdAccount[]>;
