import type { AdAccount, LoadAdAccountsConfig } from '../types/account-list.types';
export declare function loadAdAccountsFlow(partialConfig?: Partial<LoadAdAccountsConfig>): Promise<AdAccount[]>;
