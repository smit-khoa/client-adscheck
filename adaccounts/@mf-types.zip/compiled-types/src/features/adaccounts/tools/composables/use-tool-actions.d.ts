import { type ToolActionsInstance } from '@/composables/tool-actions/create-tool-actions';
export declare function useToolActions(): ToolActionsInstance;
