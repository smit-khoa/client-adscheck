import type { ToolGroup } from '@/types/tool-action.types';
interface Props {
    groups: ToolGroup[];
    selectedFunctionId: string | null;
    selectedFunctionIds: string[];
}
declare const _default: import("vue").DefineComponent<Props, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {} & {
    "select-function": (id: string) => any;
}, string, import("vue").PublicProps, Readonly<Props> & Readonly<{
    "onSelect-function"?: ((id: string) => any) | undefined;
}>, {}, {}, {}, {}, string, import("vue").ComponentProvideOptions, false, {}, any>;
export default _default;
