import type { ToolFunction } from "@/types/tool-action.types";
interface Props {
    fn: ToolFunction;
    stepNumber: number;
    expanded: boolean;
    runnable: boolean;
}
declare var __VLS_21: {};
type __VLS_Slots = {} & {
    default?: (props: typeof __VLS_21) => any;
};
declare const __VLS_component: import("vue").DefineComponent<Props, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {} & {
    toggle: () => any;
    remove: () => any;
}, string, import("vue").PublicProps, Readonly<Props> & Readonly<{
    onToggle?: (() => any) | undefined;
    onRemove?: (() => any) | undefined;
}>, {}, {}, {}, {}, string, import("vue").ComponentProvideOptions, false, {}, any>;
declare const _default: __VLS_WithSlots<typeof __VLS_component, __VLS_Slots>;
export default _default;
type __VLS_WithSlots<T, S> = T & {
    new (): {
        $slots: S;
    };
};
