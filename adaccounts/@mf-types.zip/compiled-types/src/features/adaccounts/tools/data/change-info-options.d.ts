import type { ToolFieldOption } from '@/types/tool-action.types';
export declare const CHANGE_INFO_CURRENCY_KEEP_VALUE = "__keep__";
export declare const CHANGE_INFO_TIMEZONE_KEEP_VALUE = "__keep__";
export declare const CHANGE_INFO_CURRENCY_OPTIONS: ToolFieldOption[];
export interface ChangeInfoTimezoneOption {
    id: number;
    name: string;
    timezone: string;
}
export declare const CHANGE_INFO_TIMEZONE_SOURCE: ChangeInfoTimezoneOption[];
export declare const CHANGE_INFO_TIMEZONE_OPTIONS: ToolFieldOption[];
