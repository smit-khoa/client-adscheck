import type { ToolFieldOption } from '@/types/tool-action.types';
export declare const CHANGE_INFO_COUNTRY_KEEP_VALUE = "__keep__";
export declare const CHANGE_INFO_COUNTRY_OPTIONS: ToolFieldOption[];
