import type { LoadAdAccountsConfig } from '../types/account-list.types';
declare const _default: import("vue").DefineComponent<{}, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {} & {
    load: (config: LoadAdAccountsConfig) => any;
}, string, import("vue").PublicProps, Readonly<{}> & Readonly<{
    onLoad?: ((config: LoadAdAccountsConfig) => any) | undefined;
}>, {}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
export default _default;
