import type { ToolFunction } from '../../bm-tool-types';
export declare function useBmActions(): {
    functions: ToolFunction[];
    expandedId: import("vue").Ref<string | null, string | null>;
    expandedFunction: import("vue").ComputedRef<ToolFunction | null>;
    formValues: Record<string, string | boolean>;
    toggleExpand: (id: string) => void;
};
