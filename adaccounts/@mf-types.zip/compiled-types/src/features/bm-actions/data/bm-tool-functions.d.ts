import type { ToolFunction } from '../../bm-tool-types';
export declare const BM_TOOL_FUNCTIONS: ToolFunction[];
