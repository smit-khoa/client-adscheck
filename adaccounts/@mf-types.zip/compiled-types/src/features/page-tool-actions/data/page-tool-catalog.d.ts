import type { ToolFunction } from '../../tool-actions';
export declare const PAGE_TOOL_FUNCTIONS: ToolFunction[];
