import { type ToolActionsInstance } from '../../tool-actions';
export declare function usePageToolActions(): ToolActionsInstance;
