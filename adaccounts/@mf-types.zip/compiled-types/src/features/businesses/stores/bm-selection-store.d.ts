export declare const useBmSelectionStore: import("pinia").StoreDefinition<"bm-selection", Pick<{
    selectedBmIds: import("vue").Ref<Set<string> & Omit<Set<string>, keyof Set<any>>, Set<string> | (Set<string> & Omit<Set<string>, keyof Set<any>>)>;
}, "selectedBmIds">, Pick<{
    selectedBmIds: import("vue").Ref<Set<string> & Omit<Set<string>, keyof Set<any>>, Set<string> | (Set<string> & Omit<Set<string>, keyof Set<any>>)>;
}, never>, Pick<{
    selectedBmIds: import("vue").Ref<Set<string> & Omit<Set<string>, keyof Set<any>>, Set<string> | (Set<string> & Omit<Set<string>, keyof Set<any>>)>;
}, never>>;
