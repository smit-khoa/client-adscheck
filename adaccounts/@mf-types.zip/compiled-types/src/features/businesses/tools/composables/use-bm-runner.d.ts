export interface RunSummary {
    ok: number;
    total: number;
    errors: string[];
    warnings: string[];
}
interface RunContext {
    bmIds: string[];
    values: Record<string, string | boolean>;
}
interface RunnerDef {
    requiresBm: boolean;
    execute(ctx: RunContext, settings: {
        threads: number;
        delayMs: number;
    }): Promise<RunSummary>;
}
export declare function parseEmails(text: string): string[];
export declare function parseLines(text: string): string[];
export declare function parseDomains(text: string): string[];
export declare function useBmRunner(): {
    threads: import("vue").Ref<number, number>;
    delayMs: import("vue").Ref<number, number>;
    isRunning: import("vue").Ref<boolean, boolean>;
    getRunner: (id: string | null) => RunnerDef | null;
    run: (id: string, ctx: RunContext) => Promise<RunSummary>;
};
export {};
