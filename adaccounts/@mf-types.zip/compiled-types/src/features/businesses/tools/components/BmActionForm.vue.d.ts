import type { ToolFunction } from '../types';
interface Props {
    fn: ToolFunction;
    selectedCount: number;
    values?: Record<string, string | boolean>;
    showHeader?: boolean;
    variant?: 'default' | 'panel-two';
}
declare const _default: import("vue").DefineComponent<Props, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<Props> & Readonly<{}>, {
    variant: "default" | "panel-two";
    showHeader: boolean;
}, {}, {}, {}, string, import("vue").ComponentProvideOptions, false, {}, any>;
export default _default;
