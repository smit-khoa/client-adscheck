export interface ViewerColumn {
    field: string;
    name: string;
    width: number;
}
export type ViewerRow = Record<string, string | number> & {
    id: string;
};
export interface ViewerAction {
    label: string;
    variant?: 'default' | 'destructive' | 'outline';
    run: (bmId: string, id: string) => Promise<{
        ok: boolean;
        message: string;
    }>;
}
export interface ViewerConfig {
    title: string;
    columns: ViewerColumn[];
    load: (bmId: string) => Promise<{
        ok: true;
        rows: ViewerRow[];
    } | {
        ok: false;
        message: string;
    }>;
    actions: ViewerAction[];
}
export declare const VIEWER_CONFIGS: Record<string, ViewerConfig>;
