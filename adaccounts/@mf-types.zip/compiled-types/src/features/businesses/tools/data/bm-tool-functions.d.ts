import type { ToolFunction } from '../types';
export declare const BM_TOOL_FUNCTIONS: ToolFunction[];
