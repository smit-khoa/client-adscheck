import type { BmRow, BmRowPatch } from '../types/bm-data-loading.types';
interface Connection<T> {
    data?: T[];
    paging?: {
        next?: string;
    };
}
interface BusinessNode {
    id?: string;
    name?: string;
    is_disabled_for_integrity_reasons?: boolean;
    sharing_eligibility_status?: string;
    created_time?: string;
    verification_status?: string;
    permitted_roles?: string[];
    agencies?: Connection<{
        id?: string;
        name?: string;
    }>;
    partners?: Connection<{
        id?: string;
        name?: string;
    }>;
    owned_apps?: Connection<{
        id?: string;
        name?: string;
    }>;
}
export interface AdAccountNode {
    account_id?: string;
    account_status?: number;
    adtrust_dsl?: number | string;
    currency?: string;
    amount_spent?: number | string;
    name?: string;
    created_time?: string;
}
export declare function formatCreatedDate(value?: string): string;
export declare function mapBusinessToRow(node: BusinessNode): BmRow;
export declare function mapAssetPatch(bmId: string, payload: Record<string, Connection<Record<string, unknown>> | undefined>, groups: {
    page: boolean;
    instagram: boolean;
    whatsapp: boolean;
}): BmRowPatch;
export declare function summarizeAccounts(accounts: AdAccountNode[]): string;
export declare function mapAdAccountPatch(bmId: string, owned: AdAccountNode[], client: AdAccountNode[], groups: {
    bmAccount: boolean;
    share: boolean;
    limit: boolean;
}): BmRowPatch;
export declare function normalizeError(error: unknown): Error;
export {};
