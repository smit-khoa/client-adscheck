import { type BmLoadConfig } from '../types/bm-data-loading.types';
interface Props {
    disabled?: boolean;
}
declare const _default: import("vue").DefineComponent<Props, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {} & {
    submit: (value: BmLoadConfig) => any;
}, string, import("vue").PublicProps, Readonly<Props> & Readonly<{
    onSubmit?: ((value: BmLoadConfig) => any) | undefined;
}>, {
    disabled: boolean;
}, {}, {}, {}, string, import("vue").ComponentProvideOptions, false, {}, any>;
export default _default;
