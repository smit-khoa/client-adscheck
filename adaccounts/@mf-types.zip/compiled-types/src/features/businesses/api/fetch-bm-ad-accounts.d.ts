import type { BmRowPatch } from '../types/bm-data-loading.types';
interface AdAccountFetchOptions {
    bmAccount: boolean;
    share: boolean;
    limit: boolean;
}
export declare function fetchBmAdAccounts(bmId: string, options: AdAccountFetchOptions): Promise<BmRowPatch>;
export {};
