import type { BmRowPatch } from '../types/bm-data-loading.types';
export declare function fetchBmAdmins(bmId: string): Promise<BmRowPatch>;
