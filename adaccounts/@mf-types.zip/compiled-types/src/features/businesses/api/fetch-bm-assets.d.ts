import type { BmRowPatch } from '../types/bm-data-loading.types';
interface AssetFetchOptions {
    page: boolean;
    instagram: boolean;
    whatsapp: boolean;
}
export declare function fetchBmAssets(bmId: string, options: AssetFetchOptions): Promise<BmRowPatch>;
export {};
