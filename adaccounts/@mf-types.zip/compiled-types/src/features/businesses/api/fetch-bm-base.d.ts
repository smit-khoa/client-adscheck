import type { BmBaseFetchConfig, BmRow } from '../types/bm-data-loading.types';
export declare function fetchBmBaseRows(config: BmBaseFetchConfig): Promise<BmRow[]>;
