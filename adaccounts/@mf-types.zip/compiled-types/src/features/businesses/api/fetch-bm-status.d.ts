import type { BmRow, BmRowPatch } from '../types/bm-data-loading.types';
export declare function fetchBmStatusOverview(rows: BmRow[]): Promise<BmRowPatch[]>;
export declare function fetchBmStatus(rows: BmRow[]): Promise<BmRowPatch[]>;
