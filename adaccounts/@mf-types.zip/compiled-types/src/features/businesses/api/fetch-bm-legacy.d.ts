import type { BmRowPatch } from '../types/bm-data-loading.types';
export declare function fetchBmLegacyType(bmId: string): Promise<BmRowPatch>;
export declare function fetchBmLegacyQuality(bmId: string): Promise<BmRowPatch>;
