export declare function usePageSelection(): {
    selectedIds: import("vue").Ref<Set<string> & Omit<Set<string>, keyof Set<any>>, Set<string> | (Set<string> & Omit<Set<string>, keyof Set<any>>)>;
    isSelected: (id: string) => boolean;
    toggleSelect: (id: string) => void;
    toggleSelectAll: (ids: string[]) => void;
    selectedCount: import("vue").ComputedRef<number>;
};
