import type { ToolFunction } from '@/types/tool-action.types';
export declare const PAGE_TOOL_FUNCTIONS: ToolFunction[];
