import type { PageFetchConfig, PageRow, ResolvedPageRef } from '../types/page-manager.types';
export declare function createDefaultPageFetchConfig(): PageFetchConfig;
export declare function clampPageLimit(value: number): number;
export declare function resolvePageRefs(config: PageFetchConfig): Promise<ResolvedPageRef[]>;
export declare function preloadPageTokens(): Promise<void>;
export declare function createPendingPageRows(refs: ResolvedPageRef[]): PageRow[];
export declare function fetchPageDetails(refs: ResolvedPageRef[], includePosts: boolean): Promise<PageRow[]>;
export declare function applyStatusDetails(rows: PageRow[]): Promise<void>;
export declare function applyMonetizationDetails(rows: PageRow[]): Promise<string | null>;
