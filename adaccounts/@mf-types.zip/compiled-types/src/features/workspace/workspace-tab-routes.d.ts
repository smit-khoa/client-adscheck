import type { RouteLocationNormalizedLoaded } from 'vue-router';
import type { WorkspaceTab } from './types/workspace.types';
export declare const WORKSPACE_TAB_ROUTE_NAMES: Record<WorkspaceTab, string>;
export declare const WORKSPACE_TAB_ROUTE_PATHS: Record<WorkspaceTab, string>;
export declare function workspaceTabFromRoute(route: RouteLocationNormalizedLoaded): WorkspaceTab | null;
export declare function workspaceTabPath(tab: WorkspaceTab): string;
