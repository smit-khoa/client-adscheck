import type { WorkspaceTab, WorkspaceTabMeta } from '../types/workspace.types';
export declare const WORKSPACE_TABS: WorkspaceTabMeta[];
export declare const DEFAULT_WORKSPACE_TAB: WorkspaceTab;
export declare const useWorkspaceTabStore: import("pinia").StoreDefinition<"adaccounts-workspace-tabs", Pick<{
    activeTab: import("vue").Ref<WorkspaceTab, WorkspaceTab>;
    activeTabMeta: import("vue").ComputedRef<WorkspaceTabMeta>;
    setActiveTab: (tab: WorkspaceTab) => void;
    tabs: WorkspaceTabMeta[];
}, "tabs" | "activeTab">, Pick<{
    activeTab: import("vue").Ref<WorkspaceTab, WorkspaceTab>;
    activeTabMeta: import("vue").ComputedRef<WorkspaceTabMeta>;
    setActiveTab: (tab: WorkspaceTab) => void;
    tabs: WorkspaceTabMeta[];
}, "activeTabMeta">, Pick<{
    activeTab: import("vue").Ref<WorkspaceTab, WorkspaceTab>;
    activeTabMeta: import("vue").ComputedRef<WorkspaceTabMeta>;
    setActiveTab: (tab: WorkspaceTab) => void;
    tabs: WorkspaceTabMeta[];
}, "setActiveTab">>;
