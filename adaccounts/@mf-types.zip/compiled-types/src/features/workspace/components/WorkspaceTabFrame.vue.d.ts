import type { WorkspaceTab, WorkspaceTabMeta } from "../types/workspace.types";
interface Props {
    tabs: WorkspaceTabMeta[];
    activeTab: WorkspaceTab;
    activeTabMeta: WorkspaceTabMeta;
}
declare var __VLS_22: {
    activeTab: WorkspaceTab;
    activeTabMeta: WorkspaceTabMeta;
}, __VLS_32: {
    activeTab: WorkspaceTab;
    activeTabMeta: WorkspaceTabMeta;
}, __VLS_34: {
    activeTab: WorkspaceTab;
    activeTabMeta: WorkspaceTabMeta;
}, __VLS_39: {
    activeTab: WorkspaceTab;
    activeTabMeta: WorkspaceTabMeta;
};
type __VLS_Slots = {} & {
    toolbar?: (props: typeof __VLS_22) => any;
} & {
    main?: (props: typeof __VLS_32) => any;
} & {
    'function-panel-one'?: (props: typeof __VLS_34) => any;
} & {
    'panel-two'?: (props: typeof __VLS_39) => any;
};
declare const __VLS_component: import("vue").DefineComponent<Props, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {} & {
    "update:activeTab": (value: WorkspaceTab) => any;
}, string, import("vue").PublicProps, Readonly<Props> & Readonly<{
    "onUpdate:activeTab"?: ((value: WorkspaceTab) => any) | undefined;
}>, {}, {}, {}, {}, string, import("vue").ComponentProvideOptions, false, {}, any>;
declare const _default: __VLS_WithSlots<typeof __VLS_component, __VLS_Slots>;
export default _default;
type __VLS_WithSlots<T, S> = T & {
    new (): {
        $slots: S;
    };
};
