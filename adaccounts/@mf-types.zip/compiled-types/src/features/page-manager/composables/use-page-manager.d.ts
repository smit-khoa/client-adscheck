import type { PageLoadProgress, PageRow } from '../types/page-manager.types';
declare function loadPages(): Promise<void>;
export declare function usePageManager(): {
    config: {
        source: import("..").PageSource;
        ids: string;
        pageLimit: number;
        options: {
            status: boolean;
            tick: boolean;
            follow: boolean;
            post: boolean;
            pageLive: boolean;
            monetize: boolean;
        };
    };
    rows: import("vue").Ref<{
        id: string;
        rowKey: string;
        pageId: string;
        name: string;
        avatar: string;
        status: string;
        live: boolean | null;
        role: string;
        bm: string;
        bmName: string;
        adminCount: number | null;
        createdDate: string;
        likes: number | null;
        follows: number | null;
        type: string;
        postCount: number | null;
        pageTick: string;
        pageLive: string;
        monetize: string;
        profileId: string;
        error: string;
    }[], PageRow[] | {
        id: string;
        rowKey: string;
        pageId: string;
        name: string;
        avatar: string;
        status: string;
        live: boolean | null;
        role: string;
        bm: string;
        bmName: string;
        adminCount: number | null;
        createdDate: string;
        likes: number | null;
        follows: number | null;
        type: string;
        postCount: number | null;
        pageTick: string;
        pageLive: string;
        monetize: string;
        profileId: string;
        error: string;
    }[]>;
    isLoading: import("vue").Ref<boolean, boolean>;
    error: import("vue").Ref<string | null, string | null>;
    progress: import("vue").Ref<{
        total: number;
        loaded: number;
        step: string;
    }, PageLoadProgress | {
        total: number;
        loaded: number;
        step: string;
    }>;
    loadPages: typeof loadPages;
};
export {};
