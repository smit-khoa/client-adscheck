export { default as PageManagerView } from './pages/PageManagerView.vue';
export { usePageManager } from './composables/use-page-manager';
export type { PageFetchConfig, PageFetchOptions, PageRow, PageSource } from './types/page-manager.types';
