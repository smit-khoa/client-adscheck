import type { CheckHoldResult } from './adaccount-check-hold';
import type { AdAccount, OwnerBusiness } from '../types/account-list.types';
export interface AdAccountSeed {
    account_id: string;
    name?: string;
    account_status?: number;
    currency?: string;
    owner_business?: OwnerBusiness;
}
export declare function normalizeAccountId(value: string | number | undefined): string;
export declare function toActId(accountId: string): string;
export declare function parseIdsText(value: string): string[];
export declare function isBusinessAccount(seed: AdAccountSeed): boolean;
export declare function matchesAccountType(seed: AdAccountSeed, accountType: 'all' | 'personal' | 'bm'): boolean;
export declare function mapAdAccountRow(seed: AdAccountSeed, detail?: unknown, payment?: unknown, hiddenLimit?: number, checkHold?: CheckHoldResult): AdAccount;
