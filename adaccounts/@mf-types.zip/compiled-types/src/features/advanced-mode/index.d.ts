export { default as AdvancedModePlaceholder } from './pages/AdvancedModePlaceholder.vue';
