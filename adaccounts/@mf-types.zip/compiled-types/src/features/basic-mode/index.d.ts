export { default as BasicModeView } from './pages/BasicModeView.vue';
