import { type BmLoadConfig } from '../types/bm-data-loading.types';
declare const _default: import("vue").DefineComponent<{}, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {} & {
    submit: (value: BmLoadConfig) => any;
}, string, import("vue").PublicProps, Readonly<{}> & Readonly<{
    onSubmit?: ((value: BmLoadConfig) => any) | undefined;
}>, {}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
export default _default;
