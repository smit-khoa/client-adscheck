import type { BmLoadConfig, BmRow } from '../types/bm-data-loading.types';
interface Props {
    rows: BmRow[];
    loading: boolean;
    config: BmLoadConfig | null;
}
declare const _default: import("vue").DefineComponent<Props, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<Props> & Readonly<{}>, {}, {}, {}, {}, string, import("vue").ComponentProvideOptions, false, {}, any>;
export default _default;
