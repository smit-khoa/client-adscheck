export type BmLoadSource = 'all' | 'byId';
export type BmAdvancedGroup = 'status' | 'page' | 'limit' | 'bmAccount' | 'partner' | 'admin' | 'instagram' | 'whatsapp' | 'share';
export type BmPatchGroup = BmAdvancedGroup;
export type BmAdvancedOptions = Record<BmAdvancedGroup, boolean>;
export interface BmLoadConfig {
    source: BmLoadSource;
    ids: string[];
    advEnabled: boolean;
    adv: BmAdvancedOptions;
    concurrency: number;
}
export interface BmRow {
    id: string;
    bmId: string;
    name: string;
    status: string;
    disabled: boolean;
    type: string;
    tier: string;
    role: string;
    notify: string;
    partnerCount?: number;
    appCount?: number;
    createdDate: string;
    appealStatus?: string;
    appealLabel?: string;
    appealDaysLeft?: string;
    pageCount?: number;
    assetSummary?: string;
    limit?: string;
    currency?: string;
    spend?: string;
    accountBm?: string;
    accountShare?: string;
    admin?: string;
    instagramCount?: number;
    whatsappCount?: number;
    loadingGroups: Partial<Record<BmPatchGroup, boolean>>;
    errorGroups: Partial<Record<BmPatchGroup, string>>;
}
export type BmRowPatch = Partial<Omit<BmRow, 'id' | 'bmId' | 'loadingGroups' | 'errorGroups'>> & {
    bmId: string;
};
export interface BmBaseFetchConfig {
    source: BmLoadSource;
    ids: string[];
    includePartner: boolean;
    pageSize: number;
}
export declare const BM_ADVANCED_GROUPS: BmAdvancedGroup[];
export declare const DEFAULT_BM_ADVANCED_OPTIONS: BmAdvancedOptions;
export declare const DEFAULT_BM_LOAD_CONFIG: BmLoadConfig;
