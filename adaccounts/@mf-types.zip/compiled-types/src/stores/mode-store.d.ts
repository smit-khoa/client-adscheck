export type AdAccountsMode = 'basic' | 'advanced';
export declare const useModeStore: import("pinia").StoreDefinition<"adaccounts-mode", Pick<{
    mode: import("vue").Ref<AdAccountsMode, AdAccountsMode>;
    setMode: (value: AdAccountsMode) => void;
    toggle: () => void;
}, "mode">, Pick<{
    mode: import("vue").Ref<AdAccountsMode, AdAccountsMode>;
    setMode: (value: AdAccountsMode) => void;
    toggle: () => void;
}, never>, Pick<{
    mode: import("vue").Ref<AdAccountsMode, AdAccountsMode>;
    setMode: (value: AdAccountsMode) => void;
    toggle: () => void;
}, "toggle" | "setMode">>;
