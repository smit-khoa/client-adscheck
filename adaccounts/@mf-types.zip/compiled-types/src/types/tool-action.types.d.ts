import type { IconName } from '@mf2/shared-ui/icons';
export type ToolFieldType = 'text' | 'number' | 'textarea' | 'select' | 'searchable-select' | 'switch' | 'checkbox' | 'radio' | 'section' | 'file';
export interface ToolFieldOption {
    value: string;
    label: string;
}
export interface ToolFieldCondition {
    key: string;
    equals: string;
}
export interface ToolFieldSchema {
    key: string;
    label: string;
    type: ToolFieldType;
    placeholder?: string;
    default?: string | number | boolean;
    options?: ToolFieldOption[];
    accept?: string;
    sectionTitle?: string;
    sectionDescription?: string;
    sectionIcon?: IconName;
    summaryKey?: string;
    summaryText?: string;
    optionSearchPlaceholder?: string;
    group?: string;
    fullWidth?: boolean;
    required?: boolean;
    sensitive?: boolean;
    hint?: string;
    description?: string;
    note?: string;
    showWhen?: ToolFieldCondition;
    disabledWhen?: ToolFieldCondition | ToolFieldCondition[];
    enabledWhen?: ToolFieldCondition | ToolFieldCondition[];
    enabledWhenAny?: ToolFieldCondition[];
}
export interface ToolFunction {
    id: string;
    label: string;
    icon?: IconName;
    disabled?: boolean;
    disabledReason?: string;
    fields?: ToolFieldSchema[];
}
export interface ToolGroup {
    id: string;
    label: string;
    icon?: IconName;
    functions: ToolFunction[];
}
