export * from './compiled-types/src/App.vue';
export { default } from './compiled-types/src/App.vue';